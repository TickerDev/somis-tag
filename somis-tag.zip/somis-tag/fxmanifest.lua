fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Somis'
description 'Simple discord tag check'
server_scripts {
    'config.lua',
    'server.lua'
}
