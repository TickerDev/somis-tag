config = {
token = "",
guild_id = ""
}
